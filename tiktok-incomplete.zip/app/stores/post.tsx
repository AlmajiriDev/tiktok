import { create } from "zustand";
import { createJSONStorage, devtools, persist } from "zustand/middleware";
import useGetRandomUsers from "../hooks/useGetRandomUsers";
import useGetProfileByUserId from "../hooks/useGetProfileByUserId";
import { Post, PostWithProfile, Profile } from "../types";
import useGetAllPosts from "../hooks/useGetAllPosts";
import useGetPostsByUser from "../hooks/useGetPostsByUserId";
import useGetPostById from "../hooks/useGetPostById";

interface PostStore {
    allPosts: PostWithProfile[]
    postsByUser: Post[]
    postById: PostWithProfile | null
    
    setAllPosts: () => void
    setPostByUser: (userId: string) => void
    setPostById: (postId: string) => void
}

export const usePostStore = create<PostStore>()(
    devtools(
        persist(
            (set) =>({
                allPosts: [],
                postsByUser: [],
                postById: null,

                setAllPosts: async () => {
                    const result = await useGetAllPosts()
                    set({allPosts: result})
                },
                setPostByUser: async (userId: string) => {
                    const result = await useGetPostsByUser(userId)
                    set({postsByUser: result})
                },
                setPostById: async (postId: string ) => {
                    const result = await useGetPostById(postId)
                    set({postById: result})
                }
            }),
            {
                name: 'store',
                storage: createJSONStorage(() => localStorage)
            }
        )
    )

)